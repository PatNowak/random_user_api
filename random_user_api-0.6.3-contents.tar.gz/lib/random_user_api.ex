defmodule RandomUserApi do
end
